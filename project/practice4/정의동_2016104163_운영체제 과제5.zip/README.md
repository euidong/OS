# LRU Algorithm

### Input
- frame's number : 10 ~ 200

### Condition
- reference string's type : frame's number * 5
- reference string's number : frame's number
- generate reference string by random 

### Output
- Scheduling View
